This image is copied from Wikimedia Commons. 

- https://upload.wikimedia.org/wikipedia/commons/b/b6/SCD_algebraic_notation.svg
- https://commons.wikimedia.org/wiki/File:SCD_algebraic_notation.svg

License:
- This image is licensed under the GNU Free Documentation License.  https://commons.wikimedia.org/wiki/Commons:GNU_Free_Documentation_License,_version_1.2
- This image is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0) license. https://creativecommons.org/licenses/by-sa/3.0/deed.en
