This image has been copied from xkcd.com

- https://imgs.xkcd.com/comics/regular_expressions.png
- https://www.xkcd.com/208/

License:
- https://creativecommons.org/licenses/by-nc/2.5/
- This file is licensed under Creative Commons Attribution-NonCommercial 2.5 Generic (CC BY-NC 2.5) License. https://creativecommons.org/licenses/by-nc/2.5/
